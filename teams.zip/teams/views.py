from django.shortcuts import render, redirect, get_object_or_404
from .models import Team, Player
from .forms import TeamForm, PlayerForm
from django.http import HttpResponseRedirect
from django.forms import formset_factory
from geopy.distance import distance
from django.http import JsonResponse, HttpResponseBadRequest
from django.http import HttpResponse
from .team_matching import find_nearby_team
from .utils import find_nearby_team
import time
import logging
from django.http import HttpResponseNotAllowed
from django.urls import reverse

logger = logging.getLogger(__name__)

def find_rival(request):
    if request.method == "POST":
        try:
            team_id = int(request.POST.get('team_id'))
            team = Team.objects.get(id=team_id)
            logger.debug("Iniciando la búsqueda de rival para el equipo %s...", team)
            best_rival, teams_analyzed = find_nearby_team(team, max_distance=10, timeout=30)
            if best_rival is not None:
                logger.debug("Rival encontrado: %s", best_rival)
                return HttpResponseRedirect(reverse('rival_details', args=[team_id, best_rival.id]))
            else:
                logger.warning("No se encontró ningún rival cercano para el equipo %s", team)
                return render(request, 'teams/list_teams.html', {'error': 'No se encontró ningún rival cercano'})
        except Exception as e:
            logger.exception("Error en find_rival: %s", e)
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return HttpResponseNotAllowed(['POST'])

def console_log(request):
    message = request.GET.get('message', '')
    print(f"DEBUG: {message}")
    return HttpResponse("Logged.")

def rival_details(request, team_id, rival_id):
    try:
        team = Team.objects.get(id=team_id)
        max_distance = 30  # Cambia el valor a 30 km
        rival, teams_analyzed = find_nearby_team(team, max_distance)

        context = {
            'team': team,
            'rival': rival
        }
        return render(request, 'teams/rival_details.html', context)
    except Exception as e:
        logger.exception("Error en rival_details: %s", e)
        return JsonResponse({'error': str(e)}, status=500)

    
    
def delete_all_teams(request):
    Team.objects.all().delete()
    return HttpResponse("Todos los equipos han sido eliminados.")


def list_teams(request):
    teams = Team.objects.all()
    return render(request, 'teams/list_teams.html', {'teams': teams})



def index(request):
    if request.method == 'POST':
        form = TeamForm(request.POST)
        if form.is_valid():
            team = form.save(commit=False)
            team.latitude = request.POST.get('latitude')
            team.longitude = request.POST.get('longitude')
            team.save()
            return redirect('create_players', team_id=team.id)
    else:
        form = TeamForm()
        latitude = request.GET.get('latitude', None)
        longitude = request.GET.get('longitude', None)

    return render(request, 'teams/index.html', {'form': form, 'latitude': latitude, 'longitude': longitude})


def register_team(request):
    if request.method == 'POST':
        form = TeamForm(request.POST)
        if form.is_valid():
            team = form.save(commit=False)
            team.latitude = request.POST.get('latitude')
            team.longitude = request.POST.get('longitude')
            team.save()
            return redirect('create_players', team_id=team.id)
    else:
        form = TeamForm()
        latitude = request.GET.get('latitude', None)
        longitude = request.GET.get('longitude', None)

    return render(request, 'teams/register_team.html', {'form': form, 'latitude': latitude, 'longitude': longitude})


def create_players(request, team_id):
    team = Team.objects.get(id=team_id)
    if not team_id:
        return redirect('home')

    PlayerFormSet = formset_factory(PlayerForm, extra=team.num_players, max_num=team.num_players)

    if request.method == 'POST':
        formset = PlayerFormSet(request.POST, prefix='player')
        if formset.is_valid():
            for form in formset:
                player = form.save(commit=False)
                player.team = team
                player.save()
            return redirect('find_rival', team_id=team_id)
    else:
        formset = PlayerFormSet(prefix='player')

    return render(request, 'teams/create_players.html', {'formset': formset, 'team': team})


    
        
def create_team(request):
    if request.method == 'POST':
        form = TeamForm(request.POST)
        if form.is_valid():
            team = form.save(commit=False)
            team.latitude = float(request.POST.get('latitude', 0))
            team.longitude = float(request.POST.get('longitude', 0))
            team.save()
            return redirect('create_players', team_id=team.id)
    else:
        form = TeamForm()
    return render(request, 'teams/create_team.html', {'form': form})
