from django.db import models

class Team(models.Model):
    name = models.CharField(max_length=100)
    num_players = models.PositiveIntegerField()
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    whatsapp_number = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return self.name

        
        
        
class Player(models.Model):
    name = models.CharField(max_length=100)
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    speed = models.IntegerField()
    control = models.IntegerField()
    shot = models.IntegerField()
    defense = models.IntegerField()
    attack = models.IntegerField()
