from geopy.distance import distance
from .models import Team

def find_nearby_team(team, max_distance):
    nearby_teams = Team.objects.exclude(id=team.id)
    for nearby_team in nearby_teams:
        team_coords = (team.latitude, team.longitude)
        nearby_team_coords = (nearby_team.latitude, nearby_team.longitude)
        if distance(team_coords, nearby_team_coords).km <= max_distance:
            return nearby_team
    return None

