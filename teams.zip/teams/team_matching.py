from geopy.distance import great_circle
from .models import Team, Player
import time

def find_nearby_team(team, max_distance=30, timeout=30):
    nearby_teams = Team.objects.exclude(id=team.id).filter(num_players=team.num_players)

    team_players = Player.objects.filter(team=team)
    team_avg_skill = sum([p.speed + p.control + p.shot + p.defense + p.attack for p in team_players]) / len(team_players)

    best_rival = None
    best_skill_difference = float('inf')
    teams_analyzed = 0

    start_time = time.monotonic()  # Usa time.monotonic() en lugar de time.time()

    for nearby_team in nearby_teams:
        if time.monotonic() - start_time > timeout:  # Usa time.monotonic() en lugar de time.time()
            print("Se alcanzó el tiempo límite.")
            break

        team_coords = (team.latitude, team.longitude)
        nearby_team_coords = (nearby_team.latitude, nearby_team.longitude)

        # Filtra los equipos en función de la distancia máxima
        if great_circle(team_coords, nearby_team_coords).km <= max_distance:
            teams_analyzed += 1
            print(f"Equipo analizado: {nearby_team}")

            rival_players = Player.objects.filter(team=nearby_team)
            rival_avg_skill = sum([p.speed + p.control + p.shot + p.defense + p.attack for p in rival_players]) / len(rival_players)

            skill_difference = abs(team_avg_skill - rival_avg_skill)

            if skill_difference < best_skill_difference and skill_difference < team_avg_skill * 0.5:
                best_skill_difference = skill_difference
                best_rival = nearby_team

    return best_rival, teams_analyzed

