from django import forms
from .models import Team, Player

class TeamForm(forms.ModelForm):
    num_players = forms.IntegerField(label='Número de jugadores', min_value=2, max_value=10)

    class Meta:
        model = Team
        fields = ('name', 'num_players', 'whatsapp_number',)
        labels = {
            'name': 'Nombre',
            'whatsapp_number': 'Número de Whatsapp',
        }

class PlayerForm(forms.ModelForm):
    name = forms.CharField(label='Nombre de tu jugador #', required=True)
    speed = forms.IntegerField(label='Velocidad', min_value=1, max_value=10, widget=forms.NumberInput(attrs={'type': 'range'}))
    control = forms.IntegerField(label='Control', min_value=1, max_value=10, widget=forms.NumberInput(attrs={'type': 'range'}))
    shot = forms.IntegerField(label='Disparo', min_value=1, max_value=10, widget=forms.NumberInput(attrs={'type': 'range'}))
    defense = forms.IntegerField(label='Defensa', min_value=1, max_value=10, widget=forms.NumberInput(attrs={'type': 'range'}))
    attack = forms.IntegerField(label='Ataque', min_value=1, max_value=10, widget=forms.NumberInput(attrs={'type': 'range'}))

    class Meta:
        model = Player
        fields = ('name', 'speed', 'control', 'shot', 'defense', 'attack')