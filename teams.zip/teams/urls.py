from django.urls import path
from . import views
from django.views.generic import RedirectView
from django.contrib import messages
from .views import index, create_players, list_teams, delete_all_teams, rival_details, console_log



urlpatterns = [
    path('', views.index, name='home'),
    path('create_players/<int:team_id>/', views.create_players, name='create_players'),
    path('favicon.ico', RedirectView.as_view(url='/static/images/favicon.ico', permanent=True)),
    path('list_teams/', views.list_teams, name='list_teams'),
    path('delete_all_teams/', views.delete_all_teams, name='delete_all_teams'),
    path('rival_details/<int:team_id>/<int:rival_id>/', views.rival_details, name='rival_details'),
    path('console_log/', views.console_log, name='console_log'),
    path('find_rival/', views.find_rival, name='find_rival'),
]
